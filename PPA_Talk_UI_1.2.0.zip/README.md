# PPA Talk — UI update 1.2.0

Package: `com.ppatalk.app`

## Included
- Existing Firebase Email/Password sign-up and login
- Existing Firestore public text-post feed and create-post flow
- Facebook-inspired PPA Talk home layout: blue/white header, feed composer, stories-style row, post cards, action row styling, and bottom navigation for Home, Friends, Reels, Notifications, and Profile
- Search and sign-out actions in the top bar

## Important implementation status
This update is a UI/layout pass only. Like/Unlike, comments, share actions, friend requests, friend list, profile editing, notifications, photo upload, and reels upload are not implemented yet. The Friends, Reels, Notifications, and Profile destinations are currently informational placeholders. The Like/Comment/Share row is visual only.

## Firebase setup
- Add your own `google-services.json` for package `com.ppatalk.app`.
- Enable Email/Password Authentication and Cloud Firestore.
- Review and deploy `firestore.rules.example` before testing.
- Firebase Storage is not added or required in this UI-only update.

Open the project in Android Studio, sync Gradle, and run on a device/emulator. This environment does not include Android Gradle tooling, so a successful APK build has not been verified here.
