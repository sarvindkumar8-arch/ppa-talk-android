package com.ppatalk.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Query
import java.text.DateFormat
import java.util.Date

private val Navy = Color(0xFF123A8C)
private val Orange = Color(0xFFFF8500)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { PPATalkApp() }
    }
}

@Composable
fun PPATalkApp() {
    var user by remember { mutableStateOf(FirebaseAuth.getInstance().currentUser) }
    MaterialTheme(colorScheme = lightColorScheme(primary = Navy, secondary = Orange)) {
        if (user == null) {
            AuthScreen(onAuthenticated = { user = FirebaseAuth.getInstance().currentUser })
        } else {
            MainSocialApp(
                uid = user!!.uid,
                email = user?.email.orEmpty(),
                displayName = user?.displayName?.takeIf { it.isNotBlank() } ?: user?.email?.substringBefore("@").orEmpty(),
                onSignOut = {
                    FirebaseAuth.getInstance().signOut()
                    user = null
                }
            )
        }
    }
}

@Composable
fun AuthScreen(onAuthenticated: () -> Unit) {
    var isSignUp by remember { mutableStateOf(true) }
    var name by remember { mutableStateOf("") }
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf("") }

    Column(
        modifier = Modifier.fillMaxSize().padding(24.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text("PPA Talk", style = MaterialTheme.typography.displaySmall,
            fontWeight = FontWeight.ExtraBold, color = Navy)
        Text("Create. Connect. Share.", color = Orange)
        Spacer(Modifier.height(28.dp))
        Text(if (isSignUp) "Create your account" else "Welcome back",
            style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(16.dp))

        if (isSignUp) {
            OutlinedTextField(name, { name = it }, label = { Text("Full name") },
                modifier = Modifier.fillMaxWidth(), singleLine = true)
            Spacer(Modifier.height(8.dp))
        }
        OutlinedTextField(email, { email = it }, label = { Text("Email address") },
            modifier = Modifier.fillMaxWidth(), singleLine = true,
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email))
        Spacer(Modifier.height(8.dp))
        OutlinedTextField(password, { password = it }, label = { Text("Password") },
            modifier = Modifier.fillMaxWidth(), singleLine = true,
            visualTransformation = PasswordVisualTransformation(),
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password))
        Spacer(Modifier.height(12.dp))

        Button(
            onClick = {
                message = ""
                if (email.isBlank() || password.length < 6 || (isSignUp && name.isBlank())) {
                    message = "Enter valid details. Password must be at least 6 characters."
                    return@Button
                }
                busy = true
                val auth = FirebaseAuth.getInstance()
                if (isSignUp) {
                    auth.createUserWithEmailAndPassword(email.trim(), password)
                        .addOnSuccessListener { result ->
                            val firebaseUser = result.user
                            val profileName = name.trim()
                            firebaseUser?.updateProfile(
                                com.google.firebase.auth.UserProfileChangeRequest.Builder()
                                    .setDisplayName(profileName).build()
                            )?.addOnCompleteListener {
                                if (firebaseUser != null) {
                                    val profile = hashMapOf(
                                        "uid" to firebaseUser.uid,
                                        "displayName" to profileName,
                                        "email" to email.trim(),
                                        "visibility" to "public",
                                        "createdAt" to com.google.firebase.firestore.FieldValue.serverTimestamp()
                                    )
                                    FirebaseFirestore.getInstance().collection("users")
                                        .document(firebaseUser.uid).set(profile)
                                        .addOnCompleteListener { task ->
                                            busy = false
                                            if (task.isSuccessful) onAuthenticated()
                                            else message = task.exception?.localizedMessage ?: "Profile setup failed."
                                        }
                                } else {
                                    busy = false
                                    message = "Account created, but profile setup failed."
                                }
                            }
                        }
                        .addOnFailureListener { busy = false; message = it.localizedMessage ?: "Sign up failed." }
                } else {
                    auth.signInWithEmailAndPassword(email.trim(), password)
                        .addOnSuccessListener { busy = false; onAuthenticated() }
                        .addOnFailureListener { busy = false; message = it.localizedMessage ?: "Login failed." }
                }
            },
            enabled = !busy,
            modifier = Modifier.fillMaxWidth()
        ) {
            Text(if (busy) "Please wait..." else if (isSignUp) "Sign Up" else "Login")
        }
        TextButton(onClick = { isSignUp = !isSignUp; message = "" }) {
            Text(if (isSignUp) "Already have an account? Login" else "New here? Create account")
        }
        if (message.isNotBlank()) Text(message, color = MaterialTheme.colorScheme.error)
        Spacer(Modifier.height(12.dp))
        Text("Public community • Be respectful and stay safe",
            style = MaterialTheme.typography.bodySmall, color = Color.Gray)
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainSocialApp(uid: String, email: String, displayName: String, onSignOut: () -> Unit) {
    var selected by remember { mutableStateOf("Home") }
    val blue = Color(0xFF1877F2)
    Scaffold(
        containerColor = Color(0xFFF0F2F5),
        topBar = {
            Column {
                TopAppBar(
                    colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.White),
                    title = { Text("PPA Talk", color = blue, fontWeight = FontWeight.ExtraBold) },
                    actions = {
                        IconButton(onClick = { selected = "Search" }) {
                            Icon(Icons.Default.Search, contentDescription = "Search", tint = Color.DarkGray)
                        }
                        IconButton(onClick = { selected = "Notifications" }) {
                            Icon(Icons.Default.NotificationsNone, contentDescription = "Notifications", tint = Color.DarkGray)
                        }
                        IconButton(onClick = onSignOut) {
                            Icon(Icons.Default.Logout, contentDescription = "Sign out", tint = Color.DarkGray)
                        }
                    }
                )
                if (selected == "Home") {
                    Row(Modifier.fillMaxWidth().background(Color.White).padding(horizontal = 16.dp, vertical = 2.dp),
                        horizontalArrangement = Arrangement.SpaceBetween) {
                        TextButton(onClick = { selected = "Home" }) { Text("For you", color = blue, fontWeight = FontWeight.Bold) }
                        TextButton(onClick = { selected = "Friends" }) { Text("Friends", color = Color.DarkGray) }
                        TextButton(onClick = { selected = "Reels" }) { Text("Reels", color = Color.DarkGray) }
                    }
                }
            }
        },
        bottomBar = {
            NavigationBar(containerColor = Color.White) {
                listOf(
                    "Home" to Icons.Default.Home,
                    "Friends" to Icons.Default.People,
                    "Reels" to Icons.Default.SmartDisplay,
                    "Notifications" to Icons.Default.Notifications,
                    "Profile" to Icons.Default.Person
                ).forEach { (label, icon) ->
                    NavigationBarItem(
                        selected = selected == label,
                        onClick = { selected = label },
                        icon = { Icon(icon, contentDescription = label) },
                        label = { Text(label, maxLines = 1, overflow = TextOverflow.Ellipsis) },
                        colors = NavigationBarItemDefaults.colors(selectedIconColor = blue, selectedTextColor = blue,
                            indicatorColor = Color(0xFFE7F0FF))
                    )
                }
            }
        }
    ) { padding ->
        when (selected) {
            "Home" -> HomeFeed(Modifier.padding(padding), onCreatePost = { selected = "Create" })
            "Profile" -> SimplePage("Your profile", "$displayName\n$email\n\nProfile editing will be added in the next development phase.", Modifier.padding(padding))
            "Friends" -> SimplePage("Friends", "Friend requests and your friends list are planned for the next development phase.", Modifier.padding(padding))
            "Reels" -> SimplePage("Reels", "Reels viewing and upload will be enabled after media storage is configured.", Modifier.padding(padding))
            "Search" -> SimplePage("Search", "Discover people and public posts.", Modifier.padding(padding))
            "Create" -> CreatePostScreen(uid, displayName, email, Modifier.padding(padding))
            else -> SimplePage("Notifications", "Your activity notifications will appear here.", Modifier.padding(padding))
        }
    }
}

data class FeedPost(
    val id: String,
    val authorName: String,
    val authorEmail: String,
    val text: String,
    val createdAt: Date?
)

@Composable
fun HomeFeed(modifier: Modifier = Modifier, onCreatePost: () -> Unit = {}) {
    var posts by remember { mutableStateOf<List<FeedPost>>(emptyList()) }
    var loading by remember { mutableStateOf(true) }
    var error by remember { mutableStateOf("") }

    DisposableEffect(Unit) {
        val registration = FirebaseFirestore.getInstance().collection("posts")
            .orderBy("createdAt", Query.Direction.DESCENDING)
            .addSnapshotListener { snapshot, exception ->
                if (exception != null) {
                    error = exception.localizedMessage ?: "Could not load posts. Check Firestore rules."
                    loading = false
                } else if (snapshot != null) {
                    posts = snapshot.documents.map { doc ->
                        FeedPost(
                            id = doc.id,
                            authorName = doc.getString("authorName") ?: "PPA Talk user",
                            authorEmail = doc.getString("authorEmail") ?: "",
                            text = doc.getString("text") ?: "",
                            createdAt = doc.getTimestamp("createdAt")?.toDate()
                        )
                    }
                    loading = false
                    error = ""
                }
            }
        onDispose { registration.remove() }
    }

    LazyColumn(modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item {
            Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(0.dp), colors = CardDefaults.cardColors(containerColor = Color.White)) {
                Column(Modifier.padding(16.dp)) {
                    Text("Welcome to PPA Talk", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(4.dp))
                    Text("Connect with your community", color = Color.Gray, style = MaterialTheme.typography.bodyMedium)
                    Spacer(Modifier.height(14.dp))
                    OutlinedButton(onClick = onCreatePost, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(24.dp)) {
                        Icon(Icons.Default.Edit, contentDescription = null)
                        Spacer(Modifier.width(8.dp))
                        Text("What's on your mind?")
                    }
                }
            }
        }
        item {
            Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(0.dp), colors = CardDefaults.cardColors(containerColor = Color.White)) {
                Column(Modifier.padding(vertical = 12.dp)) {
                    Text("Stories", modifier = Modifier.padding(horizontal = 16.dp), fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(10.dp))
                    LazyRow(contentPadding = PaddingValues(horizontal = 12.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        item {
                            Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.width(72.dp)) {
                                Box(Modifier.size(58.dp).background(Color(0xFFE7F0FF), CircleShape), contentAlignment = Alignment.Center) {
                                    Icon(Icons.Default.Add, contentDescription = "Add story", tint = Color(0xFF1877F2), modifier = Modifier.size(30.dp))
                                }
                                Text("Your story", style = MaterialTheme.typography.labelSmall)
                            }
                        }
                        items(5) { index ->
                            Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.width(72.dp)) {
                                Box(Modifier.size(58.dp).padding(3.dp).background(Color(0xFF1877F2), CircleShape).padding(3.dp)
                                    .background(Color(0xFFE8ECF2), CircleShape), contentAlignment = Alignment.Center) {
                                    Icon(Icons.Default.Person, contentDescription = null, tint = Color.Gray, modifier = Modifier.size(30.dp))
                                }
                                Text("Member ${index + 1}", style = MaterialTheme.typography.labelSmall, maxLines = 1)
                            }
                        }
                    }
                }
            }
        }
        item {
            Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 2.dp), verticalAlignment = Alignment.CenterVertically) {
                Text("Latest posts", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                Spacer(Modifier.weight(1f))
                Text("Public feed", color = Color.Gray, style = MaterialTheme.typography.labelSmall)
            }
        }
        if (loading) item { Box(Modifier.fillMaxWidth().padding(24.dp), contentAlignment = Alignment.Center) { CircularProgressIndicator() } }
        if (error.isNotBlank()) item { Text(error, modifier = Modifier.padding(16.dp), color = MaterialTheme.colorScheme.error) }
        if (!loading && posts.isEmpty() && error.isBlank()) {
            item {
                Card(Modifier.fillMaxWidth().padding(horizontal = 12.dp), colors = CardDefaults.cardColors(containerColor = Color.White)) {
                    Column(Modifier.padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(Icons.Default.Forum, contentDescription = null, tint = Color(0xFF1877F2), modifier = Modifier.size(36.dp))
                        Spacer(Modifier.height(8.dp))
                        Text("No posts yet", fontWeight = FontWeight.Bold)
                        Text("Be the first to share something with the community.", color = Color.Gray)
                        TextButton(onClick = onCreatePost) { Text("Create a post") }
                    }
                }
            }
        }
        items(posts, key = { it.id }) { post ->
            Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(0.dp), colors = CardDefaults.cardColors(containerColor = Color.White)) {
                Column(Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(42.dp).background(Color(0xFFE7F0FF), CircleShape), contentAlignment = Alignment.Center) {
                            Icon(Icons.Default.Person, contentDescription = null, tint = Color(0xFF1877F2), modifier = Modifier.size(27.dp))
                        }
                        Spacer(Modifier.width(10.dp))
                        Column(Modifier.weight(1f)) {
                            Text(post.authorName, fontWeight = FontWeight.Bold)
                            Text(post.createdAt?.let { DateFormat.getDateTimeInstance(DateFormat.MEDIUM, DateFormat.SHORT).format(it) } ?: "Just now",
                                style = MaterialTheme.typography.labelSmall, color = Color.Gray)
                        }
                    }
                    if (post.text.isNotBlank()) {
                        Spacer(Modifier.height(14.dp))
                        Text(post.text, style = MaterialTheme.typography.bodyLarge)
                    }
                    Spacer(Modifier.height(14.dp))
                    HorizontalDivider(color = Color(0xFFE6E8EB))
                    Row(Modifier.fillMaxWidth().padding(vertical = 10.dp), horizontalArrangement = Arrangement.SpaceEvenly) {
                        Row(verticalAlignment = Alignment.CenterVertically) { Icon(Icons.Default.ThumbUpOffAlt, contentDescription = null, tint = Color.Gray); Spacer(Modifier.width(5.dp)); Text("Like", color = Color.Gray) }
                        Row(verticalAlignment = Alignment.CenterVertically) { Icon(Icons.Default.ChatBubbleOutline, contentDescription = null, tint = Color.Gray); Spacer(Modifier.width(5.dp)); Text("Comment", color = Color.Gray) }
                        Row(verticalAlignment = Alignment.CenterVertically) { Icon(Icons.Default.Share, contentDescription = null, tint = Color.Gray); Spacer(Modifier.width(5.dp)); Text("Share", color = Color.Gray) }
                    }
                }
            }
        }
    }
}

@Composable
fun CreatePostScreen(uid: String, displayName: String, email: String, modifier: Modifier = Modifier) {
    var postText by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf("") }
    var success by remember { mutableStateOf(false) }

    Column(modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Text("Create a post", style = MaterialTheme.typography.headlineSmall,
            fontWeight = FontWeight.Bold, color = Navy)
        Text("Share something with the PPA Talk community.", color = Color.Gray)
        OutlinedTextField(
            value = postText,
            onValueChange = { postText = it; success = false; message = "" },
            modifier = Modifier.fillMaxWidth().heightIn(min = 150.dp),
            label = { Text("What's on your mind?") },
            placeholder = { Text("Write your post...") }
        )
        Button(
            enabled = !busy && postText.isNotBlank() && postText.trim().length <= 5000,
            onClick = {
                busy = true
                message = ""
                val post = hashMapOf(
                    "uid" to uid,
                    "authorName" to displayName,
                    "authorEmail" to email,
                    "text" to postText.trim(),
                    "createdAt" to com.google.firebase.firestore.FieldValue.serverTimestamp()
                )
                FirebaseFirestore.getInstance().collection("posts").add(post)
                    .addOnSuccessListener {
                        busy = false
                        postText = ""
                        success = true
                        message = "Your post was published!"
                    }
                    .addOnFailureListener {
                        busy = false
                        message = it.localizedMessage ?: "Post failed. Check Firestore rules and connection."
                    }
            },
            modifier = Modifier.fillMaxWidth()
        ) { Text(if (busy) "Publishing..." else "Publish Post") }
        if (postText.trim().length > 5000) Text("Post must be 5,000 characters or less.", color = MaterialTheme.colorScheme.error)
        if (message.isNotBlank()) Text(message, color = if (success) Color(0xFF16803C) else MaterialTheme.colorScheme.error)
    }
}

@Composable
fun SimplePage(title: String, detail: String, modifier: Modifier = Modifier) {
    Box(modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(title, style = MaterialTheme.typography.headlineSmall, color = Navy)
            Spacer(Modifier.height(8.dp))
            Text(detail, color = Color.Gray)
        }
    }
}
